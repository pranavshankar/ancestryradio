Pandoracle
=========

*Pandora add-on to retrieve download links of songs*

**INSTALL INSTRUCTIONS:**
Download and unpack the zip file of this repository, and store it somewhere
where you can easily get to it. In Chrome, navigate to Tools->Extensions, and
make sure that Developer mode is on. Click 'Load unpacked extension...' and
then simply find and select the Pandoracle directory that you unzipped earlier.

**TO USE:**
When you navigate to the Pandora website, a download button will appear after
the thumb down button shortly after the page loads. Clicking the download button
will send the current song's information to the Pandoracle server, which will
search for download links to the song and return them to you.

![Alt text](/static/img/example.png?raw=true "Optional Title")

**WARNING:**
We, the developers of Pandoracle, take absolutely no responsibility
for any consequences of the actions of users of this chrome extension. This
extension is meant only for retrieving download links to Public Domain and
Creative Commons Music, OR music that you LEGALLY own the rights to.